import './ChatScreen.css';

const ChatScreen = () => {
    return (
    <div className='Screen'>
    
    </div>
    )
}

export default ChatScreen;