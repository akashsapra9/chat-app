import './App.css';
import ChatPage from './Components/ChatScreen/ChatPage/ChatPage';
// import MessageBoxHolder from './Components/ChatScreen/MessageBox/MessageBoxHolder/MessageBoxHolder';
// import SignupPage from './Components/Signup/SignupPage/signupPage';
// import LoginPage from './Components/Signup/SignupPage/signupPage';
// import Holder from './Components/ChatScreen/MessagePannel/Holder/Holder';
// import SideBar from './Components/ChatScreen/SideBar/SideBar';
// import TypingArea from './Components/ChatScreen/MessageBox/TypingArea/TypingArea';
// import LoginPage from './Components/ChatScreen/SideBar/LoginPage'
// import TopInfoPannel from './Components/ChatScreen/MessageBox/TopInfoPannel/TopInfoPannel';

function App() {
  return (
    <div className="App">
      <ChatPage />
    </div>
  );
}

export default App;